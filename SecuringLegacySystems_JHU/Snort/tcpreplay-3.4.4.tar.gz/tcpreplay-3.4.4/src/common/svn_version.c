const char SVN_Version[] = "2450";
const char *svn_version(void) {
	return SVN_Version;
}
